--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.8 (Ubuntu 12.8-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.8 (Ubuntu 12.8-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test_fragment_set;
--
-- Name: test_fragment_set; Type: DATABASE; Schema: -; Owner: patrick
--

CREATE DATABASE test_fragment_set WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE test_fragment_set OWNER TO patrick;

\connect test_fragment_set

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: fragspacedb_connectionrules; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.fragspacedb_connectionrules (
    id integer NOT NULL,
    linktype1 text,
    linktype2 text,
    bondtype smallint
);


ALTER TABLE public.fragspacedb_connectionrules OWNER TO fast_grow_server;

--
-- Name: fragspacedb_connectionrules_id_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.fragspacedb_connectionrules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fragspacedb_connectionrules_id_seq OWNER TO fast_grow_server;

--
-- Name: fragspacedb_connectionrules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.fragspacedb_connectionrules_id_seq OWNED BY public.fragspacedb_connectionrules.id;


--
-- Name: fragspacedb_terminators; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.fragspacedb_terminators (
    id integer NOT NULL,
    smiles text
);


ALTER TABLE public.fragspacedb_terminators OWNER TO fast_grow_server;

--
-- Name: fragspacedb_terminators_id_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.fragspacedb_terminators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fragspacedb_terminators_id_seq OWNER TO fast_grow_server;

--
-- Name: fragspacedb_terminators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.fragspacedb_terminators_id_seq OWNED BY public.fragspacedb_terminators.id;


--
-- Name: metadata_info; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.metadata_info (
    databaseid text,
    schemaid integer,
    changeid integer,
    dirty boolean
);


ALTER TABLE public.metadata_info OWNER TO fast_grow_server;

--
-- Name: moleculedb_external_data; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.moleculedb_external_data (
    instancekey bigint,
    data bytea
);


ALTER TABLE public.moleculedb_external_data OWNER TO fast_grow_server;

--
-- Name: moleculedb_instances; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.moleculedb_instances (
    instancekey bigint NOT NULL,
    moleculekey bigint,
    molname text,
    molid bigint,
    confdata bytea,
    linkernames bytea,
    idtoinfileidmap bytea
);


ALTER TABLE public.moleculedb_instances OWNER TO fast_grow_server;

--
-- Name: moleculedb_molecule; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.moleculedb_molecule (
    moleculekey bigint NOT NULL,
    molid bytea,
    moldata bytea
);


ALTER TABLE public.moleculedb_molecule OWNER TO fast_grow_server;

--
-- Name: propertydb_instanceproperties; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_instanceproperties (
    prop_key bigint,
    anykeys bigint,
    prop_value text
);


ALTER TABLE public.propertydb_instanceproperties OWNER TO fast_grow_server;

--
-- Name: propertydb_instancesubsets_saved; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_instancesubsets_saved (
    subsetentrykey integer NOT NULL,
    subsetkey bigint,
    anykeys bigint
);


ALTER TABLE public.propertydb_instancesubsets_saved OWNER TO fast_grow_server;

--
-- Name: propertydb_instancesubsets_saved_subsetentrykey_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.propertydb_instancesubsets_saved_subsetentrykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertydb_instancesubsets_saved_subsetentrykey_seq OWNER TO fast_grow_server;

--
-- Name: propertydb_instancesubsets_saved_subsetentrykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.propertydb_instancesubsets_saved_subsetentrykey_seq OWNED BY public.propertydb_instancesubsets_saved.subsetentrykey;


--
-- Name: propertydb_moleculeproperties; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_moleculeproperties (
    prop_key bigint,
    anykeys bigint,
    prop_value text
);


ALTER TABLE public.propertydb_moleculeproperties OWNER TO fast_grow_server;

--
-- Name: propertydb_moleculesubsets_saved; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_moleculesubsets_saved (
    subsetentrykey integer NOT NULL,
    subsetkey bigint,
    anykeys bigint
);


ALTER TABLE public.propertydb_moleculesubsets_saved OWNER TO fast_grow_server;

--
-- Name: propertydb_moleculesubsets_saved_subsetentrykey_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.propertydb_moleculesubsets_saved_subsetentrykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertydb_moleculesubsets_saved_subsetentrykey_seq OWNER TO fast_grow_server;

--
-- Name: propertydb_moleculesubsets_saved_subsetentrykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.propertydb_moleculesubsets_saved_subsetentrykey_seq OWNED BY public.propertydb_moleculesubsets_saved.subsetentrykey;


--
-- Name: propertydb_pocketproperties; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_pocketproperties (
    prop_key bigint,
    anykeys bigint,
    prop_value text
);


ALTER TABLE public.propertydb_pocketproperties OWNER TO fast_grow_server;

--
-- Name: propertydb_pocketsubsets_saved; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_pocketsubsets_saved (
    subsetentrykey integer NOT NULL,
    subsetkey bigint,
    anykeys bigint
);


ALTER TABLE public.propertydb_pocketsubsets_saved OWNER TO fast_grow_server;

--
-- Name: propertydb_pocketsubsets_saved_subsetentrykey_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.propertydb_pocketsubsets_saved_subsetentrykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertydb_pocketsubsets_saved_subsetentrykey_seq OWNER TO fast_grow_server;

--
-- Name: propertydb_pocketsubsets_saved_subsetentrykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.propertydb_pocketsubsets_saved_subsetentrykey_seq OWNED BY public.propertydb_pocketsubsets_saved.subsetentrykey;


--
-- Name: propertydb_propertynames; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_propertynames (
    prop_key bigint NOT NULL,
    prop_type integer,
    prop_name text
);


ALTER TABLE public.propertydb_propertynames OWNER TO fast_grow_server;

--
-- Name: propertydb_proteinproperties; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_proteinproperties (
    prop_key bigint,
    anykeys bigint,
    prop_value text
);


ALTER TABLE public.propertydb_proteinproperties OWNER TO fast_grow_server;

--
-- Name: propertydb_proteinsubsets_saved; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_proteinsubsets_saved (
    subsetentrykey integer NOT NULL,
    subsetkey bigint,
    anykeys bigint
);


ALTER TABLE public.propertydb_proteinsubsets_saved OWNER TO fast_grow_server;

--
-- Name: propertydb_proteinsubsets_saved_subsetentrykey_seq; Type: SEQUENCE; Schema: public; Owner: fast_grow_server
--

CREATE SEQUENCE public.propertydb_proteinsubsets_saved_subsetentrykey_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.propertydb_proteinsubsets_saved_subsetentrykey_seq OWNER TO fast_grow_server;

--
-- Name: propertydb_proteinsubsets_saved_subsetentrykey_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: fast_grow_server
--

ALTER SEQUENCE public.propertydb_proteinsubsets_saved_subsetentrykey_seq OWNED BY public.propertydb_proteinsubsets_saved.subsetentrykey;


--
-- Name: propertydb_savedsubsetsnames; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.propertydb_savedsubsetsnames (
    subsetkey bigint NOT NULL,
    subsettype integer,
    subsetdata bytea
);


ALTER TABLE public.propertydb_savedsubsetsnames OWNER TO fast_grow_server;

--
-- Name: rayvolumematrixdb_discretization; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.rayvolumematrixdb_discretization (
    rays_per_depth integer,
    max_width real,
    depth_interval real,
    bin_size real,
    type smallint
);


ALTER TABLE public.rayvolumematrixdb_discretization OWNER TO fast_grow_server;

--
-- Name: rayvolumematrixdb_linkers; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.rayvolumematrixdb_linkers (
    descriptorkey bigint NOT NULL,
    instancekey bigint NOT NULL,
    linkername text NOT NULL,
    infileid integer NOT NULL
);


ALTER TABLE public.rayvolumematrixdb_linkers OWNER TO fast_grow_server;

--
-- Name: rayvolumematrixdb_matrix_data; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.rayvolumematrixdb_matrix_data (
    descriptorkey bigint NOT NULL,
    depth real,
    volume real,
    base_vectors bytea,
    widths bytea
);


ALTER TABLE public.rayvolumematrixdb_matrix_data OWNER TO fast_grow_server;

--
-- Name: searchpointsdb_search_point_counts; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.searchpointsdb_search_point_counts (
    pointkey bigint NOT NULL,
    pointtype smallint NOT NULL,
    count integer
);


ALTER TABLE public.searchpointsdb_search_point_counts OWNER TO fast_grow_server;

--
-- Name: searchpointsdb_search_point_mapping; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.searchpointsdb_search_point_mapping (
    mappingkey bigint NOT NULL,
    pointkey bigint NOT NULL
);


ALTER TABLE public.searchpointsdb_search_point_mapping OWNER TO fast_grow_server;

--
-- Name: searchpointsdb_search_points; Type: TABLE; Schema: public; Owner: fast_grow_server
--

CREATE TABLE public.searchpointsdb_search_points (
    pointkey bigint,
    pointtype smallint,
    "position" bytea
);


ALTER TABLE public.searchpointsdb_search_points OWNER TO fast_grow_server;

--
-- Name: fragspacedb_connectionrules id; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.fragspacedb_connectionrules ALTER COLUMN id SET DEFAULT nextval('public.fragspacedb_connectionrules_id_seq'::regclass);


--
-- Name: fragspacedb_terminators id; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.fragspacedb_terminators ALTER COLUMN id SET DEFAULT nextval('public.fragspacedb_terminators_id_seq'::regclass);


--
-- Name: propertydb_instancesubsets_saved subsetentrykey; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instancesubsets_saved ALTER COLUMN subsetentrykey SET DEFAULT nextval('public.propertydb_instancesubsets_saved_subsetentrykey_seq'::regclass);


--
-- Name: propertydb_moleculesubsets_saved subsetentrykey; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculesubsets_saved ALTER COLUMN subsetentrykey SET DEFAULT nextval('public.propertydb_moleculesubsets_saved_subsetentrykey_seq'::regclass);


--
-- Name: propertydb_pocketsubsets_saved subsetentrykey; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketsubsets_saved ALTER COLUMN subsetentrykey SET DEFAULT nextval('public.propertydb_pocketsubsets_saved_subsetentrykey_seq'::regclass);


--
-- Name: propertydb_proteinsubsets_saved subsetentrykey; Type: DEFAULT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinsubsets_saved ALTER COLUMN subsetentrykey SET DEFAULT nextval('public.propertydb_proteinsubsets_saved_subsetentrykey_seq'::regclass);


--
-- Data for Name: fragspacedb_connectionrules; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.fragspacedb_connectionrules (id, linktype1, linktype2, bondtype) FROM stdin;
\.
COPY public.fragspacedb_connectionrules (id, linktype1, linktype2, bondtype) FROM '$$PATH$$/3145.dat';

--
-- Data for Name: fragspacedb_terminators; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.fragspacedb_terminators (id, smiles) FROM stdin;
\.
COPY public.fragspacedb_terminators (id, smiles) FROM '$$PATH$$/3147.dat';

--
-- Data for Name: metadata_info; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.metadata_info (databaseid, schemaid, changeid, dirty) FROM stdin;
\.
COPY public.metadata_info (databaseid, schemaid, changeid, dirty) FROM '$$PATH$$/3149.dat';

--
-- Data for Name: moleculedb_external_data; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.moleculedb_external_data (instancekey, data) FROM stdin;
\.
COPY public.moleculedb_external_data (instancekey, data) FROM '$$PATH$$/3150.dat';

--
-- Data for Name: moleculedb_instances; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.moleculedb_instances (instancekey, moleculekey, molname, molid, confdata, linkernames, idtoinfileidmap) FROM stdin;
\.
COPY public.moleculedb_instances (instancekey, moleculekey, molname, molid, confdata, linkernames, idtoinfileidmap) FROM '$$PATH$$/3151.dat';

--
-- Data for Name: moleculedb_molecule; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.moleculedb_molecule (moleculekey, molid, moldata) FROM stdin;
\.
COPY public.moleculedb_molecule (moleculekey, molid, moldata) FROM '$$PATH$$/3152.dat';

--
-- Data for Name: propertydb_instanceproperties; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_instanceproperties (prop_key, anykeys, prop_value) FROM stdin;
\.
COPY public.propertydb_instanceproperties (prop_key, anykeys, prop_value) FROM '$$PATH$$/3153.dat';

--
-- Data for Name: propertydb_instancesubsets_saved; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_instancesubsets_saved (subsetentrykey, subsetkey, anykeys) FROM stdin;
\.
COPY public.propertydb_instancesubsets_saved (subsetentrykey, subsetkey, anykeys) FROM '$$PATH$$/3154.dat';

--
-- Data for Name: propertydb_moleculeproperties; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_moleculeproperties (prop_key, anykeys, prop_value) FROM stdin;
\.
COPY public.propertydb_moleculeproperties (prop_key, anykeys, prop_value) FROM '$$PATH$$/3156.dat';

--
-- Data for Name: propertydb_moleculesubsets_saved; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_moleculesubsets_saved (subsetentrykey, subsetkey, anykeys) FROM stdin;
\.
COPY public.propertydb_moleculesubsets_saved (subsetentrykey, subsetkey, anykeys) FROM '$$PATH$$/3157.dat';

--
-- Data for Name: propertydb_pocketproperties; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_pocketproperties (prop_key, anykeys, prop_value) FROM stdin;
\.
COPY public.propertydb_pocketproperties (prop_key, anykeys, prop_value) FROM '$$PATH$$/3159.dat';

--
-- Data for Name: propertydb_pocketsubsets_saved; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_pocketsubsets_saved (subsetentrykey, subsetkey, anykeys) FROM stdin;
\.
COPY public.propertydb_pocketsubsets_saved (subsetentrykey, subsetkey, anykeys) FROM '$$PATH$$/3160.dat';

--
-- Data for Name: propertydb_propertynames; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_propertynames (prop_key, prop_type, prop_name) FROM stdin;
\.
COPY public.propertydb_propertynames (prop_key, prop_type, prop_name) FROM '$$PATH$$/3162.dat';

--
-- Data for Name: propertydb_proteinproperties; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_proteinproperties (prop_key, anykeys, prop_value) FROM stdin;
\.
COPY public.propertydb_proteinproperties (prop_key, anykeys, prop_value) FROM '$$PATH$$/3163.dat';

--
-- Data for Name: propertydb_proteinsubsets_saved; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_proteinsubsets_saved (subsetentrykey, subsetkey, anykeys) FROM stdin;
\.
COPY public.propertydb_proteinsubsets_saved (subsetentrykey, subsetkey, anykeys) FROM '$$PATH$$/3164.dat';

--
-- Data for Name: propertydb_savedsubsetsnames; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.propertydb_savedsubsetsnames (subsetkey, subsettype, subsetdata) FROM stdin;
\.
COPY public.propertydb_savedsubsetsnames (subsetkey, subsettype, subsetdata) FROM '$$PATH$$/3166.dat';

--
-- Data for Name: rayvolumematrixdb_discretization; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.rayvolumematrixdb_discretization (rays_per_depth, max_width, depth_interval, bin_size, type) FROM stdin;
\.
COPY public.rayvolumematrixdb_discretization (rays_per_depth, max_width, depth_interval, bin_size, type) FROM '$$PATH$$/3167.dat';

--
-- Data for Name: rayvolumematrixdb_linkers; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.rayvolumematrixdb_linkers (descriptorkey, instancekey, linkername, infileid) FROM stdin;
\.
COPY public.rayvolumematrixdb_linkers (descriptorkey, instancekey, linkername, infileid) FROM '$$PATH$$/3168.dat';

--
-- Data for Name: rayvolumematrixdb_matrix_data; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.rayvolumematrixdb_matrix_data (descriptorkey, depth, volume, base_vectors, widths) FROM stdin;
\.
COPY public.rayvolumematrixdb_matrix_data (descriptorkey, depth, volume, base_vectors, widths) FROM '$$PATH$$/3169.dat';

--
-- Data for Name: searchpointsdb_search_point_counts; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.searchpointsdb_search_point_counts (pointkey, pointtype, count) FROM stdin;
\.
COPY public.searchpointsdb_search_point_counts (pointkey, pointtype, count) FROM '$$PATH$$/3170.dat';

--
-- Data for Name: searchpointsdb_search_point_mapping; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.searchpointsdb_search_point_mapping (mappingkey, pointkey) FROM stdin;
\.
COPY public.searchpointsdb_search_point_mapping (mappingkey, pointkey) FROM '$$PATH$$/3171.dat';

--
-- Data for Name: searchpointsdb_search_points; Type: TABLE DATA; Schema: public; Owner: fast_grow_server
--

COPY public.searchpointsdb_search_points (pointkey, pointtype, "position") FROM stdin;
\.
COPY public.searchpointsdb_search_points (pointkey, pointtype, "position") FROM '$$PATH$$/3172.dat';

--
-- Name: fragspacedb_connectionrules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.fragspacedb_connectionrules_id_seq', 2, true);


--
-- Name: fragspacedb_terminators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.fragspacedb_terminators_id_seq', 1, true);


--
-- Name: propertydb_instancesubsets_saved_subsetentrykey_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.propertydb_instancesubsets_saved_subsetentrykey_seq', 1, false);


--
-- Name: propertydb_moleculesubsets_saved_subsetentrykey_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.propertydb_moleculesubsets_saved_subsetentrykey_seq', 1, false);


--
-- Name: propertydb_pocketsubsets_saved_subsetentrykey_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.propertydb_pocketsubsets_saved_subsetentrykey_seq', 1, false);


--
-- Name: propertydb_proteinsubsets_saved_subsetentrykey_seq; Type: SEQUENCE SET; Schema: public; Owner: fast_grow_server
--

SELECT pg_catalog.setval('public.propertydb_proteinsubsets_saved_subsetentrykey_seq', 1, false);


--
-- Name: fragspacedb_connectionrules fragspacedb_connectionrules_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.fragspacedb_connectionrules
    ADD CONSTRAINT fragspacedb_connectionrules_pkey PRIMARY KEY (id);


--
-- Name: fragspacedb_terminators fragspacedb_terminators_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.fragspacedb_terminators
    ADD CONSTRAINT fragspacedb_terminators_pkey PRIMARY KEY (id);


--
-- Name: moleculedb_instances moleculedb_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.moleculedb_instances
    ADD CONSTRAINT moleculedb_instances_pkey PRIMARY KEY (instancekey);


--
-- Name: moleculedb_molecule moleculedb_molecule_molid_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.moleculedb_molecule
    ADD CONSTRAINT moleculedb_molecule_molid_key UNIQUE (molid);


--
-- Name: moleculedb_molecule moleculedb_molecule_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.moleculedb_molecule
    ADD CONSTRAINT moleculedb_molecule_pkey PRIMARY KEY (moleculekey);


--
-- Name: propertydb_instanceproperties propertydb_instanceproperties_prop_key_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instanceproperties
    ADD CONSTRAINT propertydb_instanceproperties_prop_key_anykeys_key UNIQUE (prop_key, anykeys);


--
-- Name: propertydb_instancesubsets_saved propertydb_instancesubsets_saved_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instancesubsets_saved
    ADD CONSTRAINT propertydb_instancesubsets_saved_pkey PRIMARY KEY (subsetentrykey);


--
-- Name: propertydb_instancesubsets_saved propertydb_instancesubsets_saved_subsetkey_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instancesubsets_saved
    ADD CONSTRAINT propertydb_instancesubsets_saved_subsetkey_anykeys_key UNIQUE (subsetkey, anykeys);


--
-- Name: propertydb_moleculeproperties propertydb_moleculeproperties_prop_key_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculeproperties
    ADD CONSTRAINT propertydb_moleculeproperties_prop_key_anykeys_key UNIQUE (prop_key, anykeys);


--
-- Name: propertydb_moleculesubsets_saved propertydb_moleculesubsets_saved_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculesubsets_saved
    ADD CONSTRAINT propertydb_moleculesubsets_saved_pkey PRIMARY KEY (subsetentrykey);


--
-- Name: propertydb_moleculesubsets_saved propertydb_moleculesubsets_saved_subsetkey_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculesubsets_saved
    ADD CONSTRAINT propertydb_moleculesubsets_saved_subsetkey_anykeys_key UNIQUE (subsetkey, anykeys);


--
-- Name: propertydb_pocketproperties propertydb_pocketproperties_prop_key_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketproperties
    ADD CONSTRAINT propertydb_pocketproperties_prop_key_anykeys_key UNIQUE (prop_key, anykeys);


--
-- Name: propertydb_pocketsubsets_saved propertydb_pocketsubsets_saved_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketsubsets_saved
    ADD CONSTRAINT propertydb_pocketsubsets_saved_pkey PRIMARY KEY (subsetentrykey);


--
-- Name: propertydb_pocketsubsets_saved propertydb_pocketsubsets_saved_subsetkey_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketsubsets_saved
    ADD CONSTRAINT propertydb_pocketsubsets_saved_subsetkey_anykeys_key UNIQUE (subsetkey, anykeys);


--
-- Name: propertydb_propertynames propertydb_propertynames_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_propertynames
    ADD CONSTRAINT propertydb_propertynames_pkey PRIMARY KEY (prop_key);


--
-- Name: propertydb_proteinproperties propertydb_proteinproperties_prop_key_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinproperties
    ADD CONSTRAINT propertydb_proteinproperties_prop_key_anykeys_key UNIQUE (prop_key, anykeys);


--
-- Name: propertydb_proteinsubsets_saved propertydb_proteinsubsets_saved_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinsubsets_saved
    ADD CONSTRAINT propertydb_proteinsubsets_saved_pkey PRIMARY KEY (subsetentrykey);


--
-- Name: propertydb_proteinsubsets_saved propertydb_proteinsubsets_saved_subsetkey_anykeys_key; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinsubsets_saved
    ADD CONSTRAINT propertydb_proteinsubsets_saved_subsetkey_anykeys_key UNIQUE (subsetkey, anykeys);


--
-- Name: propertydb_savedsubsetsnames propertydb_savedsubsetsnames_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_savedsubsetsnames
    ADD CONSTRAINT propertydb_savedsubsetsnames_pkey PRIMARY KEY (subsetkey);


--
-- Name: rayvolumematrixdb_linkers rayvolumematrixdb_linkers_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.rayvolumematrixdb_linkers
    ADD CONSTRAINT rayvolumematrixdb_linkers_pkey PRIMARY KEY (descriptorkey, instancekey, infileid, linkername);


--
-- Name: rayvolumematrixdb_matrix_data rayvolumematrixdb_matrix_data_pkey; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.rayvolumematrixdb_matrix_data
    ADD CONSTRAINT rayvolumematrixdb_matrix_data_pkey PRIMARY KEY (descriptorkey);


--
-- Name: searchpointsdb_search_point_counts searchpointsdb_search_point_counts_pk; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.searchpointsdb_search_point_counts
    ADD CONSTRAINT searchpointsdb_search_point_counts_pk PRIMARY KEY (pointkey, pointtype);


--
-- Name: searchpointsdb_search_point_mapping searchpointsdb_search_point_mapping_pk; Type: CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.searchpointsdb_search_point_mapping
    ADD CONSTRAINT searchpointsdb_search_point_mapping_pk PRIMARY KEY (mappingkey, pointkey);


--
-- Name: instance_key_external_data_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX instance_key_external_data_index ON public.moleculedb_external_data USING btree (instancekey);


--
-- Name: instprop_instkey_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX instprop_instkey_index ON public.propertydb_instanceproperties USING btree (anykeys);


--
-- Name: instprop_name_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX instprop_name_index ON public.propertydb_instanceproperties USING btree (anykeys);


--
-- Name: instprop_value_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX instprop_value_index ON public.propertydb_instanceproperties USING btree (prop_value, prop_key);


--
-- Name: molecule_key_insttab_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX molecule_key_insttab_index ON public.moleculedb_instances USING btree (moleculekey);


--
-- Name: molprop_molkey_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX molprop_molkey_index ON public.propertydb_moleculeproperties USING btree (anykeys);


--
-- Name: molprop_name_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX molprop_name_index ON public.propertydb_moleculeproperties USING btree (anykeys);


--
-- Name: molprop_value_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX molprop_value_index ON public.propertydb_moleculeproperties USING btree (prop_value, prop_key);


--
-- Name: pockprop_key_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX pockprop_key_index ON public.propertydb_pocketproperties USING btree (anykeys);


--
-- Name: pockprop_pokey_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX pockprop_pokey_index ON public.propertydb_pocketproperties USING btree (anykeys);


--
-- Name: pockprop_value_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX pockprop_value_index ON public.propertydb_pocketproperties USING btree (prop_value, prop_key);


--
-- Name: protprop_name_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX protprop_name_index ON public.propertydb_proteinproperties USING btree (anykeys);


--
-- Name: protprop_protkey_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX protprop_protkey_index ON public.propertydb_proteinproperties USING btree (anykeys);


--
-- Name: protprop_value_index; Type: INDEX; Schema: public; Owner: fast_grow_server
--

CREATE INDEX protprop_value_index ON public.propertydb_proteinproperties USING btree (prop_value, prop_key);


--
-- Name: moleculedb_external_data moleculedb_external_data_instancekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.moleculedb_external_data
    ADD CONSTRAINT moleculedb_external_data_instancekey_fkey FOREIGN KEY (instancekey) REFERENCES public.moleculedb_instances(instancekey) ON DELETE CASCADE;


--
-- Name: moleculedb_instances moleculedb_instances_moleculekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.moleculedb_instances
    ADD CONSTRAINT moleculedb_instances_moleculekey_fkey FOREIGN KEY (moleculekey) REFERENCES public.moleculedb_molecule(moleculekey) ON DELETE CASCADE;


--
-- Name: propertydb_instanceproperties propertydb_instanceproperties_prop_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instanceproperties
    ADD CONSTRAINT propertydb_instanceproperties_prop_key_fkey FOREIGN KEY (prop_key) REFERENCES public.propertydb_propertynames(prop_key) ON DELETE CASCADE;


--
-- Name: propertydb_instancesubsets_saved propertydb_instancesubsets_saved_subsetkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_instancesubsets_saved
    ADD CONSTRAINT propertydb_instancesubsets_saved_subsetkey_fkey FOREIGN KEY (subsetkey) REFERENCES public.propertydb_savedsubsetsnames(subsetkey) ON DELETE CASCADE;


--
-- Name: propertydb_moleculeproperties propertydb_moleculeproperties_prop_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculeproperties
    ADD CONSTRAINT propertydb_moleculeproperties_prop_key_fkey FOREIGN KEY (prop_key) REFERENCES public.propertydb_propertynames(prop_key) ON DELETE CASCADE;


--
-- Name: propertydb_moleculesubsets_saved propertydb_moleculesubsets_saved_subsetkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_moleculesubsets_saved
    ADD CONSTRAINT propertydb_moleculesubsets_saved_subsetkey_fkey FOREIGN KEY (subsetkey) REFERENCES public.propertydb_savedsubsetsnames(subsetkey) ON DELETE CASCADE;


--
-- Name: propertydb_pocketproperties propertydb_pocketproperties_prop_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketproperties
    ADD CONSTRAINT propertydb_pocketproperties_prop_key_fkey FOREIGN KEY (prop_key) REFERENCES public.propertydb_propertynames(prop_key) ON DELETE CASCADE;


--
-- Name: propertydb_pocketsubsets_saved propertydb_pocketsubsets_saved_subsetkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_pocketsubsets_saved
    ADD CONSTRAINT propertydb_pocketsubsets_saved_subsetkey_fkey FOREIGN KEY (subsetkey) REFERENCES public.propertydb_savedsubsetsnames(subsetkey) ON DELETE CASCADE;


--
-- Name: propertydb_proteinproperties propertydb_proteinproperties_prop_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinproperties
    ADD CONSTRAINT propertydb_proteinproperties_prop_key_fkey FOREIGN KEY (prop_key) REFERENCES public.propertydb_propertynames(prop_key) ON DELETE CASCADE;


--
-- Name: propertydb_proteinsubsets_saved propertydb_proteinsubsets_saved_subsetkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.propertydb_proteinsubsets_saved
    ADD CONSTRAINT propertydb_proteinsubsets_saved_subsetkey_fkey FOREIGN KEY (subsetkey) REFERENCES public.propertydb_savedsubsetsnames(subsetkey) ON DELETE CASCADE;


--
-- Name: rayvolumematrixdb_linkers rayvolumematrixdb_linkers_descriptorkey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.rayvolumematrixdb_linkers
    ADD CONSTRAINT rayvolumematrixdb_linkers_descriptorkey_fkey FOREIGN KEY (descriptorkey) REFERENCES public.rayvolumematrixdb_matrix_data(descriptorkey);


--
-- Name: rayvolumematrixdb_linkers rayvolumematrixdb_linkers_instancekey_fkey; Type: FK CONSTRAINT; Schema: public; Owner: fast_grow_server
--

ALTER TABLE ONLY public.rayvolumematrixdb_linkers
    ADD CONSTRAINT rayvolumematrixdb_linkers_instancekey_fkey FOREIGN KEY (instancekey) REFERENCES public.moleculedb_instances(instancekey);


--
-- PostgreSQL database dump complete
--

